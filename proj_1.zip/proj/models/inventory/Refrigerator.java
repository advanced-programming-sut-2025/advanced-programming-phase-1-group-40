package models.inventory;
import models.Item;

public class Refrigerator extends Inventory {
    public Refrigerator(int capacity, boolean isCapacityUnlimited) {
        super(capacity, isCapacityUnlimited);
    }

    private void pick(Item item) {

    }
}
