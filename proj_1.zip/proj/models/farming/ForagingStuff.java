package models;

public interface ForagingStuff{
    public void generate();
}
