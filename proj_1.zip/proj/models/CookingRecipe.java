package models;

import models.enums.types.FoodBuff;

public class CookingRecipe {
    private int energyOfFood;
    private String nameOfFood;
    private int sellPrice;
    private FoodBuff buff;
    private int buffDurationInHours;
    // private ingridients:
    // private source
}