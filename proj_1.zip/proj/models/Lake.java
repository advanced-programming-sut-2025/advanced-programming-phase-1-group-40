package models;

import java.util.ArrayList;

public class Lake {
    private ArrayList<Position> tiles;
}