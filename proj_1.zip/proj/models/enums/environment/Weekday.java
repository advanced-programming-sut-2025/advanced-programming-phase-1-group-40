package models.enums.environment;

public enum Weekday {
    MERCDAY,
    VENDAY,
    EARTHDAY,
    MARSADY,
    JUPYDAY,
    URANDAY,
    NEPDAY;
}
