package models.enums.types;

public enum FishingPoleType {
    TRAINING,
    BAMBOO, 
    FIBERGLASS,
    IRIDIUM;
}
