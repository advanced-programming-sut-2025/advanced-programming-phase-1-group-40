package models.enums.types;

public enum MushroomTypes {
    COMMON_MUSHROOM,
    RED_MUSHROOM,
    PURPLE_MUSHROOM;
}
