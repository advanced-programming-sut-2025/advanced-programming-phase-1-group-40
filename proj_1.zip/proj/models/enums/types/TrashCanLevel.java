package models.enums.types;

public enum TrashCanLevel {
    BASIC, COPPER, IRON, GOLD, IRIDIUM;
}
