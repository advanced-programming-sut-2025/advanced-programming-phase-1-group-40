package models;

public class Transaction {

}
