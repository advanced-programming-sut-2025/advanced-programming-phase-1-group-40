package models;

public class Mineral implements ForagingStuff {
    private int sellPrice;
}