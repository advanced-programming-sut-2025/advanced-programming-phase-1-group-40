package controllers.user;

import models.Result;

public class ProfileController {
    public Result changeUsername(String newUsername) {
        return null;
    }

    public Result changeNickname(String newNickname) {
        return null;
    }

    public Result changeEmail(String newEmail) {
        return null;
    }

    public Result changePassword(String oldPassword, String newPassword) {
        return null;
    }

}
