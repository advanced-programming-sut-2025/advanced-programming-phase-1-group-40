package views;

import controllers.player.GameController;

import java.util.Scanner;

public class GameMenu implements AppMenu {
    private final GameController controller = new GameController();

    @Override
    public void check(Scanner scanner) {

    }
}
