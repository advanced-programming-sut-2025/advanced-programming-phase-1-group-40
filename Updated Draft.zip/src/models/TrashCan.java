package models;

import models.enums.types.ToolTypes;
import models.enums.types.TrashCanLevel;

import java.util.Map;

public class TrashCan extends Tools {
    private TrashCanLevel level;

    private static final Map<TrashCanLevel, Double> REFUND_RATES = Map.of(
            TrashCanLevel.BASIC, 0.0,
            TrashCanLevel.COPPER, 0.15,
            TrashCanLevel.IRON, 0.30,
            TrashCanLevel.GOLD, 0.45,
            TrashCanLevel.IRIDIUM, 0.60
    );

    public TrashCan(TrashCanLevel level) {
        super(level.name() + " Trash Can", ToolTypes.TRASH_CAN, 0);
        this.level = level;
    }

    public double getRefundRate() {
        return REFUND_RATES.get(level);
    }
}


