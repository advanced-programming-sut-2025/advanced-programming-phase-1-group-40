package models.animals;

public class Chicken extends Animal {
    void produceProduct() {

    }
}
