package models.animals;

public class Pig extends Animal {
    void produceProduct() {

    }
}
