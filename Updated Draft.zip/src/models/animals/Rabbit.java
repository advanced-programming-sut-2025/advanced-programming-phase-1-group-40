package models.animals;

public class Rabbit extends Animal {
    void produceProduct() {

    }
}
