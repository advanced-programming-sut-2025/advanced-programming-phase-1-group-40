package models.animals;

public class Cow extends Animal {
    void produceProduct() {

    }
}
