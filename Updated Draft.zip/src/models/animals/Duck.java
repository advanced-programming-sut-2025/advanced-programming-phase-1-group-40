package models.animals;

public class Duck extends Animal {
    void produceProduct() {

    }
}
