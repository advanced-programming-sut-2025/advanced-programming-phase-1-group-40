package models.animals;

public class Dinosaur extends Animal {
    void produceProduct() {

    }
}