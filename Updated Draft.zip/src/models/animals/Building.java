package models.animals;

import models.Position;
import models.enums.Capacity;

import java.util.ArrayList;

public class Building {
    Position position;
    Capacity capacity;
    ArrayList<Animal> animals;

    void addAnimal(Animal animal) {

    }

    void removeAnimal(Animal animal) {

    }
}