package models.animals;

public class Cage extends {
}
