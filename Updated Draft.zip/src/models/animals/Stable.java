package models.animals;

public class Stable extends Building{
}
