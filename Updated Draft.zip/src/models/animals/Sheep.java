package models.animals;

public class Sheep extends Animal {
    void produceProduct() {

    }
}
