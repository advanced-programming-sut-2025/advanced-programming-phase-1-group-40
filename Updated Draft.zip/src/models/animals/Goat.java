package models.animals;

public class Goat extends Animal {
    void produceProduct() {

    }
}