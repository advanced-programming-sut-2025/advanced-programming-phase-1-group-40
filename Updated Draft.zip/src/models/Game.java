package models;

public class Game {
}
