package models;

import models.enums.Quality;
import models.enums.types.ProductType;

public class Product {
    ProductType type;
    int basePrice;
    Quality quality;

    public int getPrice() {

    }
}
