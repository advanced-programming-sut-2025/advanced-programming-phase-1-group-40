package models.enums.types;

public enum ToolTypes {
    HOE,
    PICKAXE,
    AXE,
    WATERING_CAN,
    FISHING_ROD,
    SCYTHE,
    MILK_PAIL,
    SHEARS,
    BACKPACK,
    TRASH_CAN;
}

