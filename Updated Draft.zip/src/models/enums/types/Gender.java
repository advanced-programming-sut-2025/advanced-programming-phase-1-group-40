package models.enums.types;

public enum Gender {
    WOMAN,
    MAN,
    RATHER_NOT_SAY;
}
