package models.enums.types;

public enum ProductType {
    CHICKEN_EGG,
    LARGE_CHICKEN_EGG,
    DUCK_EGG,
    DUCK_FEATHER,
    RABBIT_WOOL,
    RABBIT_FOOT,
    DINOSAUR_EGG,
    COW_MILK,
    LARGE_COW_MILK,
    GOAT_MILK,
    LARGE_GOAT_MILK,
    WOOL,
    TRUFFLE;
}
