package models.enums.types;

public enum Role {
    SHOPKEEPER,
    BLACKSMITH,
    VILLAGER;
}
