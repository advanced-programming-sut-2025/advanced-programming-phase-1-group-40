package models.enums.types;

public enum PlantType {
    WHEAT;
}
