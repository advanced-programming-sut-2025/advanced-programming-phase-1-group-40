package models.enums.types;

public enum BackpackLevel {
    INITIAL, LARGE, DELUXE;
}

