package models.enums.environment;

public enum Weather {
    SUNNY,
    RAINY,
    STORM,
    SNOW;
}
