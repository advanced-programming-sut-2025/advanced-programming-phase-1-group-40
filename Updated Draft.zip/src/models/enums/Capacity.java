package models.enums;

public enum Capacity {
    NORMAL,
    BIG,
    DELUXE;
}
