package models.enums;

public enum Quality {
    NORMAL,
    SILVER,
    GOLD,
    IRIDIUM;
}
