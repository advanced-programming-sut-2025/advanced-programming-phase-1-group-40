package models;

public enum ToolLevel {
    BASIC, COPPER, IRON, GOLD, IRIDIUM;
}
