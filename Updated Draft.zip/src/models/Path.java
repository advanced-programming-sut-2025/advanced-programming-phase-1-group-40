package models;

import java.util.ArrayList;

public class Path {
    ArrayList<Position> path;
    // Position origin;
    // Position destination;
    int distanceInTiles;
    int numOfTurns;
    int energyNeeded;
    boolean isDestinationAllowed;
    boolean playerConfirmed;
}
