package controllers.user;

import models.Result;
import models.User;

public class LoginController {
    public static User getUserByUsername(String username) {

    }

    public Result login(String username, String password) {

    }

    public Result askSecurityQuestion() {

    }

    public Result validateSecurityQuestion(User user, String answerToSecurityQuestion) {

    }

    public Result forgotPassword(String username, String email) {

    }

}
