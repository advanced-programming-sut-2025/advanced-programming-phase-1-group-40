package controllers.user;

public class MainMenuController {
}
