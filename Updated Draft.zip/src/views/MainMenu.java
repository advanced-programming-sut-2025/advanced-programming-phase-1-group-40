package views;

import controllers.user.MainMenuController;

import java.util.Scanner;

public class MainMenu implements AppMenu {
    private final MainMenuController controller = new MainMenuController();

    @Override
    public void check(Scanner scanner) {

    }
}
