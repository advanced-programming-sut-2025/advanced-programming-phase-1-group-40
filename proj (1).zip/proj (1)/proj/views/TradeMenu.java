package views;

public class TradeMenu {

}
