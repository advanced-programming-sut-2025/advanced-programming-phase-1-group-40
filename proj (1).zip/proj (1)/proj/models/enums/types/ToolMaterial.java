package models.enums.types;

public enum ToolMaterial {
    BASIC,
    COPPER,
    IRON, 
    GOLD,
    IRIDIUM;
}
