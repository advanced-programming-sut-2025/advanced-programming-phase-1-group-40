package models.enums.types;

public enum ShopType {
    BLACKSMITH,
    MARNIE_RANCH,
    THE_STARDROP_SALLON,
    CARPENTER_SHOP,
    JOJAMART,
    PIERRE_GENERAL_STORE,
    FISH_SHOP;
}
