package models.enums.types;

public enum FishingRodType {
    TRAINING, BAMBOO, FIBERGLASS, IRIDIUM;
}

