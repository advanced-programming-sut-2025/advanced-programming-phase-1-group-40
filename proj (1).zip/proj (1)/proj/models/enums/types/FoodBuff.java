package models.enums.types;

public enum FoodBuff {
    NOTHING,
    MAX_ENERGY_PLUS_100,
    MAX_ENERGY_PLUS_50,
    FARMING,
    FORAGING,
    FISHING,
    MINING;
}
