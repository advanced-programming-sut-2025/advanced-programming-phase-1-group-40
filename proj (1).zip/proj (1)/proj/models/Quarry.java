package models;

import java.util.ArrayList;

public class Quarry {
    private ArrayList<Tile> tiles;
}
