package models;
import models.farming.ForagingStuff;

public class Mineral implements ForagingStuff {
    private int sellPrice;
    @Override
    public void generate() {
        // Implementation for generating foraged minerals
    }
}