package models.farming;

import models.enums.environment.*;
import java.util.*;

public class ForagingSeed extends PlantSource implements ForagingStuff{
    private ArrayList<Season> seasons;

    @Override
    public void generate(){

    }

}
