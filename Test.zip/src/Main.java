
/*
  Just Start the program from here and do nothing else here.
 */

public class Main {
    public static void main(String[] args) {

}
}
