package controllers;

public class LoginMenuController {
}
