package models;

public class Quest {
}
