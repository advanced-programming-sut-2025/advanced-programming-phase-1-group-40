package models;

public class Shop {
}
