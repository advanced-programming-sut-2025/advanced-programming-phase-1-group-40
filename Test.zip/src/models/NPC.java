package models;

public class NPC {
}
