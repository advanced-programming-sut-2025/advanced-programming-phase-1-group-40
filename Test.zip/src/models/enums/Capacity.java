package models.enums;

public enum Capacity {
}
