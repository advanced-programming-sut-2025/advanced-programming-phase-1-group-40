package models.enums;

public enum Quality {
}
