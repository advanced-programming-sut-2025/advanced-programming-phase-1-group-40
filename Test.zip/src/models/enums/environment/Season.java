package models.enums.environment;

public enum Season {
    SPRING,
    SUMMER,
    FALL,
    WINTER;
}
