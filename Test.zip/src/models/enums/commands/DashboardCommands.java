package models.enums.commands;

public enum DashboardCommands  {

}
