package models.enums.commands;


public interface Command {
}