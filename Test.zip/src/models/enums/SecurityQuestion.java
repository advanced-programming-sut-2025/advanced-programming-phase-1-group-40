package models.enums;

public enum SecurityQuestion {

    // TODO : assign an int to each question
}
