package models.enums.types;

public enum ProductType {
}
