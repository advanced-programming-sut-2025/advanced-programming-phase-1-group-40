package models.enums.types;

public enum ArtisanType {

}
