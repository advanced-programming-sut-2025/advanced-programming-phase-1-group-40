package models.enums.types;

public enum Gender {
}
