package models.enums.types;

import models.enums.environment.Season;

public enum FishType {
    SALMON("Salmon", 75, Season.FALL, false);
    // TO DO

    String name;
    int basePrice;
    Season season;
    boolean isLegendary;

    FishType(String name, int basePrice, Season season, boolean isLegendary) {
        this.name = name;
        this.basePrice = basePrice;
        this.season = season;
        this.isLegendary = isLegendary;
    }
}
