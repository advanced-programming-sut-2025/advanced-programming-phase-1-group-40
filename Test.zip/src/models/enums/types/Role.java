package models.enums.types;

public enum Role {

}
