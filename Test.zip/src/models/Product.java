package models;

public class Product {
}
