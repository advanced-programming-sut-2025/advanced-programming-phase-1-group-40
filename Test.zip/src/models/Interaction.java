package models;

public class Interaction {
}
