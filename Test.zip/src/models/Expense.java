package models;

public class Expense{

}
