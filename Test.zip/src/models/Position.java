package models;

public class Position {
    private int x;
    private int y;
}
