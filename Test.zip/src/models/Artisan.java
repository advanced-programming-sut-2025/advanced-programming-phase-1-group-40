package models;

public class Artisan {
}
