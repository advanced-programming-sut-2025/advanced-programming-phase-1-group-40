package models;

public class Friendship {
}
