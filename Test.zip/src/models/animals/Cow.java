package models.animals;

public class Cow {
}
