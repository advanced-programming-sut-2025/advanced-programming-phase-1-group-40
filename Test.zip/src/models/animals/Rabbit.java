package models.animals;

public class Rabbit {
}
