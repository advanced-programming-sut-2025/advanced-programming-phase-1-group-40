package models.animals;

public class Goat {
}
