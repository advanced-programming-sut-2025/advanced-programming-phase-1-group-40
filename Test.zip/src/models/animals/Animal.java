package models.animals;

public class Animal {
}
