package models.animals;

public class Chicken {
}
