package models.animals;

public class Duck {
}
