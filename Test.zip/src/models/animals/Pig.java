package models.animals;

public class Pig {
}
