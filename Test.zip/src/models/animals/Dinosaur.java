package models.animals;

public class Dinosaur {
}
