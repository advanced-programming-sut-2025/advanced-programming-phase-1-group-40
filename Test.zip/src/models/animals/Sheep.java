package models.animals;

public class Sheep {
}
