package views;
/*
Explanation:
- This is a view class for the ExitMenu.
- We will just use it to end the program.
 */

public class ExitMenu{

}
