package views;

/*
Explanation:
- This is a view class for the App.
- our app needs a place that handle menus (:
 */

public class AppView {
}
