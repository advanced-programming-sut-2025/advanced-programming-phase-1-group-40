package model;

public class Cook {

    public Result cook(Recipe recipe){

    }

    public Result consumeFood(Recipe recipe){

    }

}
