package model;

public class Sheep {

    @Override
    public Result collectProduct(String name){



    }

}
