package model;

import java.util.ArrayList;

public class Husbandry {

    private ArrayList<Animal> animals;
    private ArrayList<HusbandryBuilding> buildings;

    public ArrayList<Animal> getAnimals() {
        return animals;                                 // return array
    }

    public void addAnimal(Animal animal) {

        animals.add(animal);

    }

    public ArrayList<HusbandryBuilding> getBuildings() {
        return buildings;                                 // return array
    }

    public void addBuilding(HusbandryBuilding building) {

        buildings.add(building);

    }

    public void sellAnimal(String animalName) {

        // remove animal from arraylist

    }


}
