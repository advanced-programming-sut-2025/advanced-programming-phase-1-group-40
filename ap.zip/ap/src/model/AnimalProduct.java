package model;

public class AnimalProduct {

    private float quality;
    private float price;
    private int quantity;



}
