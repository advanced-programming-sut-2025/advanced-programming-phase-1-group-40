package model;

import java.util.ArrayList;

public class Refrigerator {

    private ArrayList<Food> availableFoods;

    public Result putInside(Food food){
        availableFoods.add(food);
    }

    public Result bringOut(Food food){
        // az array hazf she
    }


}
