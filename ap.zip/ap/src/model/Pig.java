package model;

public class Pig {

    @Override
    public Result collectProduct(String name){



    }

}
