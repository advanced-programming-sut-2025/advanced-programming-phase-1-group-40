package model;

public class Goat {

    @Override
    public Result collectProduct(String name){



    }


}
