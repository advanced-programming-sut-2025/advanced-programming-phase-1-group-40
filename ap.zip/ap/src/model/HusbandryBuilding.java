package model;

import enums.HusbandryBuildingType;

public class HusbandryBuilding {

    private HusbandryBuildingType buildingType;

    private String buildingName;

    private int xCoordinate,yCoordinate;

    private int capacity;

    public HusbandryBuilding(HusbandryBuildingType buildingType, String buildingName, int xCoordinate, int yCoordinate) {

        this.buildingType = buildingType;
        this.buildingName = buildingName;
        this.xCoordinate = xCoordinate;
        this.yCoordinate = yCoordinate;

    }
}
