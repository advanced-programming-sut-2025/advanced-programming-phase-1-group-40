package model;

public class Cow extends Animal{


    @Override
    public Result collectProduct(String name){



    }

}
