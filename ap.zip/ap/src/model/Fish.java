package model;

public class Fish {



}
