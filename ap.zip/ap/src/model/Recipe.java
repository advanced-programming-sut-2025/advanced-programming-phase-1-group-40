package model;

public class Recipe {



}
