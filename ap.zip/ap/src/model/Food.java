package model;

public class Food {

    protected String foodName;                                              // double check the modifier
    private int foodCount;



    Food(String foodName, int foodCount) {
        this.foodName = foodName;
    }

    public int getFoodCount() {
        return foodCount;
    }

    public void setFoodCount(int foodCount) {
        this.foodCount = foodCount;
    }

}
