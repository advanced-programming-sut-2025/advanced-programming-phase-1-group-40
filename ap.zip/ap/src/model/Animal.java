package model;


import enums.AnimalType;
import enums.HusbandryBuildingType;

import java.util.ArrayList;

public class Animal {

    private final AnimalType type;
    private final HusbandryBuildingType animalType;
    private final String animalName;
    private int friendship;
    private boolean isFedToday, isCaressedToday, hasHayShareToday;
    private ArrayList<AnimalProduct> products;
    private boolean isInside;

    public HusbandryBuildingType getAnimalType() {
        return animalType;
    }

    Animal(HusbandryBuildingType animalType, String animalName, AnimalType type) {
        this.animalType = animalType;
        this.animalName = animalName;
        this.friendship = 0;
        this.type = type;
        this.isFedToday = false;
        this.isCaressedToday = false;
        this.hasHayShareToday = true;
        this.products = new ArrayList<>();
        this.isInside = true;
    }



    public void caress(){
        this.friendship += 15;
    }

    public void milkOrShave(){
        this.friendship += 5;
    }

    public void feedGrass(){
        this.friendship += 8;
    }

    public void nofFed(){
        this.friendship -= 20;
    }

    public void stayOutSide(){
        this.friendship -= 20;
    }

    public void notCaressed(){
//        this.friendship =                         ??
    }

    public void setFriendship(int friendship) {                     // CHEAT CODE!!!
        this.friendship = friendship;
    }

    public Result showAnimal(){                                     // Result ro fix kon!!!
        return new Result(animalType, animalName, friendship, isFed, isCaressedToday);
    }

    public Result moveAnimal(String name){                          // Result ro fix kon!!!
        return new Result(animalType, animalName, friendship, isFed, isCaressedToday);
    }


    public Result feedHay(String name){                             // Result ro fix kon!!!
        return
    }

    public Result collectProduct(String name){                      // Result ro fix kon!!!
        return
    }

    public void generateProducts(){

    }


}
