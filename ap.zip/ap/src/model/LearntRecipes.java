package model;

import java.util.ArrayList;

public class LearntRecipes {

    private ArrayList<Recipe> recipes;

    public Result addLearnRecipe(Recipe recipe){
        recipes.add(recipe);
    }

    public Result showRecipes(){
        // return kone arraylisto
    }

}
