package enums;

public enum HusbandryBuildingType {

    Barn,
    BigBarn,
    DeluxeBarn,
    Coop,
    BigCoop,
    DeluxeCoop

}
