package enums;

public enum FishTypes {

    Salmon,
    Sardine,
    Shad,
    BlueDiscus,
    MidnightCarp,
    Squid,
    Tuna,
    Perch,
    Flounder,
    LionFish,
    Herring,
    GhostFish,
    Tilapia,
    Dorado,
    Sunfish,
    RainbowTrout,
    Legend,
    GlacierFish,
    Angler,
    CrimsonFish

}
