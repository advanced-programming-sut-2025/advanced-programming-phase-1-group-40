package enums;

public enum AnimalType {

    Chicken,
    Duck,
    Rabbit,
    Dino,
    Cow,
    Goat,
    Sheep,
    Pig

}
