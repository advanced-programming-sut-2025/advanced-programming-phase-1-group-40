package models;

import java.util.ArrayList;

public class Greenhouse {

    private ArrayList<Position> tiles;


}