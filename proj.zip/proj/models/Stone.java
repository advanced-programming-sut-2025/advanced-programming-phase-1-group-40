package models;
import models.enums.types.StoneType;

public class Stone {
    private StoneType type;
    private Position position;
}