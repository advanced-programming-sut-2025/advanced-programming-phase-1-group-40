package models;

public class Couple {
    User wife;
    User husband;
}
