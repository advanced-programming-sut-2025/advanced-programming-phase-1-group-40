package models;

import java.util.ArrayList;

public class Cabin {
    private ArrayList<Position> tiles;
}