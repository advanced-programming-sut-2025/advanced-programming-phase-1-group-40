package models;

import models.farming.Harvestable;

public class Fruit extends Harvestable {



}
