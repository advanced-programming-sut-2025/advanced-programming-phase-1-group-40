package models.enums;

public enum SkillLevel {
    LEVEL_ZERO,
    LEVEL_ONE, 
    LEVEL_TWO,
    LEVEL_THREE;
}
