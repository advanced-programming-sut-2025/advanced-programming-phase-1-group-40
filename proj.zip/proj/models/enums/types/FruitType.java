package models.enums.types;

public enum FruitType {
    APRICOT,
    CHERRY,
    BANANA,
    MANGO,
    ORANGE,
    PEACH,
    APPLE,
    POMEGRANATE,
    OAK_RESIN,
    MAPLE_SYRUP,
    PINE_TAR,
    SAP,
    COMMON_MUSHROOM,
    MYSTIC_SYRUP;
}
