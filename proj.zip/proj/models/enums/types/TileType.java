package models.enums.types;

public enum TileType {
    // TODO: complete this enum the right way...
    PLOWED_GROUND,
    NOT_PLOWED_GROUND,
    STONE,
    WATER,
    GRASS;
}
