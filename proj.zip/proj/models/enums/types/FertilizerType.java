package models.enums.types;

public enum FertilizerType {
    BASIC_FERTILIZER,
    QUALITY_FERTILIZER;
}
