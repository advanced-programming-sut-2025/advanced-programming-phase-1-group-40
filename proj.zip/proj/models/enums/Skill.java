package models.enums;

public enum Skill {
    FARMING,
    MINING,
    FORAGING,
    FISHING;
}
