package models.enums.commands;

public enum MainMenuCommands implements Command{
    
}
