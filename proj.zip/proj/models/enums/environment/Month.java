package models.enums.environment;

public enum Month {
    PISCES,
    ARIES,
    TAURUS,
    GEMINI,
    CANCER,
    LEO,
    VIRGO,
    LIBRA,
    SCORPIUS,
    SAGITTARIUS,
    CAPRICORNUS,
    AQUARIUS;
}
