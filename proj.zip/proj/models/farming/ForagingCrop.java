package models.farming;

public class ForagingCrop extends PlantSource implements ForagingStuff{
    private boolean isAlsoStandardCrop;
}
