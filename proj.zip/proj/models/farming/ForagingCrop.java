package models.farming;

public class ForagingCrop extends PlantSource implements ForagingStuff{
    private boolean isAlsoStandardCrop;
    @Override
    public void generate() {
        // Implementation for generating foraged crops
    }
}
