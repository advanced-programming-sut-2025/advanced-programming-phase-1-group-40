package models.farming;

public interface ForagingStuff{
    public void generate();
}
