package models.farming;
import models.*;

public class Tree extends Harvestable{

    private Fruit fruitProduct;
    private int fruitHarvestCycle;
    private boolean isBurnt;
    private boolean isGrown;
    private int cyclePercentage;


}
