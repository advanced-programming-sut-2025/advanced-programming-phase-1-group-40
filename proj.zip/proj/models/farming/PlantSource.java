package models;

public class PlantSource{
    private String name;
    private boolean isMixedSeed;
}
