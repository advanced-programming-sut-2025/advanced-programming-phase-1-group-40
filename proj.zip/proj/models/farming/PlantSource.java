package models.farming;

public class PlantSource{
    private String name;
    private boolean isMixedSeed;
}
