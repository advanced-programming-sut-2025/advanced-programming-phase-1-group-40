package models.farming;

public class Crop extends Harvestable {
    private boolean oneTime;
    int regrowthTime;
}
