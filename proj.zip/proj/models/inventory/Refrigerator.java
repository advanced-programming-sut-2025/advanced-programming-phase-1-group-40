package models.inventory;
import models.Item;
import models.*;

public class Refrigerator extends Inventory {
    public Refrigerator(int capacity, boolean isCapacityUnlimited) {
        super(capacity, isCapacityUnlimited);
    }

    private Result pick(Item item) {

    }

    private Result put(Item item){


    }

}
