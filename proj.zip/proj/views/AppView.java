package views;

public class AppView {
    public void run() {

    }
}
