package views;

import controllers.user.LoginController;

import java.util.Scanner;

public class LoginMenu implements AppMenu {
    private final LoginController controller = new LoginController();

    @Override
    public void check(Scanner scanner) {

    }
}
