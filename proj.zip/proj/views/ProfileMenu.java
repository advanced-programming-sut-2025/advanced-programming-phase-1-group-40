package views;

import controllers.user.ProfileController;

import java.util.Scanner;

public class ProfileMenu implements AppMenu {
    private final ProfileController controller = new ProfileController();

    @Override
    public void check(Scanner scanner) {

    }
}
