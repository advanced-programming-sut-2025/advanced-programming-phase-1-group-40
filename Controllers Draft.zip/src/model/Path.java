package model;

import java.util.ArrayList;

public class Path {
    ArrayList<Position> path; // including the origin and destination
    int distanceInTiles;
    int numOfTurns;
    int energyNeeded;

}
